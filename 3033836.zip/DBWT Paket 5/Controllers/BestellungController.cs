﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataModel;

namespace DBWT_Paket_5.Controllers
{
    public class BestellungController : Controller
    {
        // GET: Bestellung
        public ActionResult Index()
        {
            Dictionary<Mahlzeiten, Mahlzeitenxbestellungen> retDict = new Dictionary<Mahlzeiten, Mahlzeitenxbestellungen >();
            ViewData["dict"] = retDict;
            var name = Session["name"].ToString();
            if (HttpContext.Request.Cookies.Get("dbwt") != null)
            {
                // cookie auslesen
                HttpCookie exists = HttpContext.Request.Cookies.Get("dbwt");
                //ergebnis vorbereiten

                //Default setzten
                try
                {
                    // cookie-Wert in ein Objekt umwandeln (geben Sie in < > an, in welchen Typ)
                    Dictionary<string, Dictionary<int, int>>  fromCookie = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<int, int>>>(exists.Value);
                    if (fromCookie != null && fromCookie.ContainsKey(name))
                    {
                        // wenn alles passt
                       

                        ViewData["dict"] = retDict;
                        return View();

                    }
                    else
                    {
                        // Bestellung Leer
                        ViewBag["message"] = "Warenkorb ist Leer";
                        return View();

                    }
                    //  ViewBag.fromCookie = JsonConvert.SerializeObject(fromCookie);
                }
                catch (Exception e)
                {
                    ViewBag.fromCookie = e.Message;
                    return View();
                }
            }
            ViewBag["error"] = "ZOOMG Da ist irgendwas Schief gelaufen :/ ";
            return View();
        }

        // GET: Bestellung/Details/5
        [HttpPost]
        public ActionResult AddToList()
        {
            int anz = 0; 
            var id = Convert.ToInt32(Request["id"].ToString());
            var name = Session["name"].ToString();
            if (HttpContext.Request.Cookies.Get("dbwt") != null)
            {
                // cookie auslesen
                HttpCookie exists = HttpContext.Request.Cookies.Get("dbwt");
                //ergebnis vorbereiten

                //Default setzten
                Dictionary<string, Dictionary<int, int>> fromCookie = new Dictionary<string, Dictionary<int, int>>();
                fromCookie.Add(name, new Dictionary<int, int>());
                HttpCookie c = new HttpCookie("dbwt");

                try
                {
                    // cookie-Wert in ein Objekt umwandeln (geben Sie in < > an, in welchen Typ)
                    fromCookie = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<int, int>>>(exists.Value);
                    if (fromCookie != null && fromCookie.ContainsKey(name))
                    {

                    }
                    else
                    {
                        if (fromCookie != null)
                        {
                            fromCookie.Clear();
                        }

                        fromCookie = new Dictionary<string, Dictionary<int, int>>()
                                    {
                                            { name, null }
                                    };
                    }
                    //  ViewBag.fromCookie = JsonConvert.SerializeObject(fromCookie);
                }
                catch (Exception e)
                {
                    ViewBag.fromCookie = e.Message;
                }
                Dictionary<int, int> testarr = fromCookie[name];
                if (testarr.ContainsKey(id))
                {
                    if(anz - testarr[id] < 1 )
                    {
                        ViewBag["error"] = "Verfügbare Mahlzeit(en) bereits in Bestellung. NICHT erneut hinzugefügt";
                        return Redirect(Request.UrlReferrer.ToString());
                    }
                    testarr[id] += 1;
                    ViewBag["message"] = "Mahlzeit erneut zur bestellung hinzugefügt.";
                   
                }
                else
                {
                    if (anz < 1)
                    {
                        ViewBag["error"] = "Mahlzeit Ausverkauft.";
                        return Redirect(Request.UrlReferrer.ToString());

                    }
                    testarr.Add(id, 1);
                    ViewBag["message"] = "Mahlzeit zur bestellung hinzugefügt.";
                }
                fromCookie[name].Clear();
                // neu befüllen
                foreach (KeyValuePair<int, int> entry in  testarr)
                {
                    fromCookie[name].Add(entry.Key  , entry.Value);
                }
               // cookie neu setzten.
                c.Value = JsonConvert.SerializeObject(fromCookie);
                c.Expires = DateTime.Now.AddHours(2);
                HttpContext.Response.Cookies.Set(c);

                return View();
            }
            ViewBag["error"] = "ZOOMG Da ist irgendwas Schief gelaufen :/ ";
            return Redirect(Request.UrlReferrer.ToString());
        }

        // GET: Bestellung/Create
        [HttpPost]
        public ActionResult ChangeAmount()
        {
            // in dict packen.
            Dictionary<int, int> Best = new Dictionary<int, int>();
            // Best aus Formular befüllen
            var name = Session["name"].ToString();
            if (HttpContext.Request.Cookies.Get("dbwt") != null)
            {
                // cookie auslesen
                HttpCookie exists = HttpContext.Request.Cookies.Get("dbwt");
                //ergebnis vorbereiten

                //Default setzten
                Dictionary<string, Dictionary<int, int>> fromCookie = new Dictionary<string, Dictionary<int, int>>();
                fromCookie.Add(name, new Dictionary<int, int>());
                HttpCookie c = new HttpCookie("dbwt");

                try
                {
                    // cookie-Wert in ein Objekt umwandeln (geben Sie in < > an, in welchen Typ)
                    fromCookie = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<int, int>>>(exists.Value);
                    if (fromCookie != null && fromCookie.ContainsKey(name))
                    {

                    }
                    else
                    {
                        if (fromCookie != null)
                        {
                            fromCookie.Clear();
                        }

                        fromCookie = new Dictionary<string, Dictionary<int, int>>()
                                    {
                                            { name, null }
                                    };
                    }
                    //  ViewBag.fromCookie = JsonConvert.SerializeObject(fromCookie);
                }
                catch (Exception e)
                {
                    ViewBag.fromCookie = e.Message;
                }
                fromCookie[name].Clear();
                // neu befüllen
                foreach (KeyValuePair<int, int> entry in Best)
                {
                    fromCookie[name].Add(entry.Key, entry.Value);
                }
                // cookie neu setzten.
                c.Value = JsonConvert.SerializeObject(fromCookie);
                c.Expires = DateTime.Now.AddHours(2);
                HttpContext.Response.Cookies.Set(c);

                return View();
            }
            ViewBag["error"] = "ZOOMG Da ist irgendwas Schief gelaufen :/ ";
            return Redirect(Request.UrlReferrer.ToString());
        }

        [HttpPost]
        public ActionResult Delete()
        {
            if (HttpContext.Request.Cookies.Get("dbwt") != null)
            {
                // cookie auslesen
                HttpCookie exists = HttpContext.Request.Cookies.Get("dbwt");
                try
                {
                    // cookie-Wert in ein Objekt umwandeln (geben Sie in < > an, in welchen Typ)

                    exists.Expires = DateTime.MinValue;
                    HttpContext.Response.Cookies.Set(exists);
                    ViewBag["Message"] = "Bestellungen gelöscht.";
                    return View();
                }
                catch(Exception e)
                {
                    ViewBag["error"] = "Fehler Meldung: "+e.Message;
                    return View();
                }
               
            }
            ViewBag["error"] = "Cookie war schon Weg :/.";
            return View();
        }

        [HttpPost]
        public ActionResult Bestellen()
        {
            return View();
        }
    }
}
