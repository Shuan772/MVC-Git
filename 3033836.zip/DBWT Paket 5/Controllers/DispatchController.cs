﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataModel;
namespace DBWT_Paket_5.Controllers
{
    public class DispatchController : Controller
    {
        // GET: Dispatch
        public JsonResult Bestellungen()
        {
            var headers = Request.Headers;
            try { 
                if (headers["X-Authorize"] != "o2e1s1dpt4nwhwe")
                {
                    return Json("Authorize Failed");
                }
            }
            catch(Exception e)
            {
                return Json(e.Message);
            }
            List<Bestellungen> list = new List<Bestellungen>();

            using (var MensaContext = new Mensa())
            {
                var query = from best in MensaContext.Bestellungen
                            join be in MensaContext.Benutzer on best.Benutzer equals be.Nummer
                            where best.Bestellzeitpunkt <= DateTime.Now.AddMinutes(30)
                            //where be.Nutzername.Contains("db")
                            //select new {Vorname = be.Vorname, Nachname = be.Nachname};
                            select new { be  };

                var query2 = from bi in MensaContext.Bilder
                             select bi;

                try
                {
                   // list = query.ToList());
                }
                catch (Exception e)
                {
                    var x = e.Message;
                }

            }

            return Json(list, JsonRequestBehavior.AllowGet);
        }
    }
}